#!/bin/bash
# block-8 features for the remaining datasets/rates (after the block chain finishes on this GPU)
R=/root/autodl-tmp/TempoRAC; G=$1
until grep -q ALL_DONE $R/logs/extract_blocks_g$G.done 2>/dev/null; do sleep 30; done
cd $R/code; export PYTHONPATH=. OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 CUDA_VISIBLE_DEVICES=$G
CK=$R/pretrained/VIT_B_16x4_MAE_PT.pyth
for job in UCFRep:data/UCFRep/manifest_full.json:16 RepCountA:data/RepCountA/manifest_all.json:16 QUVA:data/QUVA/manifest.json:2,4,8,16 Countix:data/Countix/manifest.json:2,4,8,16; do
  IFS=: read N M RT <<< "$job"
  $R/env/bin/python -m temporac_cvpr.extract_features --manifest $R/$M --out $R/features/${N}_stmae_b8_p4 --ckpt $CK --encoder stmae --block 8 --rates $RT --pool 4 --via 7 --batch 48 --workers 4 --shard $G --num-shards 2 > $R/logs/extract_b8rest_${N}_g$G.log 2>&1
  echo "$N $(date)" >> $R/logs/extract_b8rest_g$G.done
done
echo ALL_DONE >> $R/logs/extract_b8rest_g$G.done
