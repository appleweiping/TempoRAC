#!/bin/bash
# intermediate ST-MAE blocks: UCFRep b8,b10,b6 -> launch up5 -> RepCount b8,b10
R=/root/autodl-tmp/TempoRAC; G=$1
cd $R/code; export PYTHONPATH=. OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 CUDA_VISIBLE_DEVICES=$G
CK=$R/pretrained/VIT_B_16x4_MAE_PT.pyth
ex() { $R/env/bin/python -m temporac_cvpr.extract_features --manifest $R/$2 --out $R/features/${1}_stmae_b${3}_p4 --ckpt $CK --encoder stmae --block $3 --rates 2,4,8 --pool 4 --via 7 --batch 48 --workers 4 --shard $G --num-shards 2 > $R/logs/extract_b${3}_${1}_g$G.log 2>&1; echo "$1 b$3 $(date)" >> $R/logs/extract_blocks_g$G.done; }
for B in 8 10 6; do ex UCFRep data/UCFRep/manifest_full.json $B; done
if [ "$G" = 0 ]; then
  until [ $(grep -c "UCFRep b6" $R/logs/extract_blocks_g1.done 2>/dev/null) -ge 1 ]; do sleep 20; done
  setsid nohup $R/env/bin/python -m temporac_cvpr.launch $R/code/temporac_cvpr/specs/up5.json --max-per-gpu 1 > $R/logs/queue_up5.log 2>&1 < /dev/null &
fi
for B in 8 10; do ex RepCountA data/RepCountA/manifest_all.json $B; done
echo ALL_DONE >> $R/logs/extract_blocks_g$G.done
