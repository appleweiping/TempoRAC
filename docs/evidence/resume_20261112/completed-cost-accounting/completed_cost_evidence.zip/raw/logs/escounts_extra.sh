R=/root/autodl-tmp/TempoRAC; cd $R/code; export PYTHONPATH=. PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
run() { mkdir -p $R/runs/baselines/$1; CUDA_VISIBLE_DEVICES=0 $R/env/bin/python -m temporac_cvpr.escounts_official --manifest $2 --splits $3 --source $R/third_party/EveryShotCounts --encoder $R/pretrained/VIT_B_16x4_MAE_PT.pyth --decoder $R/pretrained/escounts_repcount.pyth --out $R/runs/baselines/$1 > $R/runs/baselines/$1/stdout.log 2>&1; }
run escounts_official_testwarp $R/data/RepCountA_warp/warp_pw3.json test_warp
run escounts_official_quva $R/data/QUVA/manifest.json test
run escounts_official_ucfrep $R/data/UCFRep/manifest_full.json test
echo ESC_EXTRA_DONE
